import psutil
import requests
import socket
import time

CENTRAL_SERVER = "http://localhost:8080/api/metrics"  # Local backend

def collect_and_send():
    data = {
        "hostname": socket.gethostname(),
        "cpu": psutil.cpu_percent(),
        "memory": psutil.virtual_memory().percent,
        "disk": psutil.disk_usage('C:\\').percent
    }
    try:
        requests.post(CENTRAL_SERVER, json=data, timeout=5)
        print(f"[OK] Sent metrics: {data}")
    except Exception as e:
        print(f"[ERROR] {e}")

if __name__ == "__main__":
    while True:
        collect_and_send()
        time.sleep(60)  # send every 1 min
