//package healthcheck.example.monitor.contoller;
//
//import healthcheck.example.monitor.model.Metrics;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.*;
//
//import java.time.LocalDateTime;
//import java.util.*;
//import java.util.concurrent.ConcurrentHashMap;
//
//@Controller
//public class MetricsController {
//    private Map<String, Metrics> metricsMap = new ConcurrentHashMap<>();
//    private String status; // "UP" or "DOWN"
//
//
//    @PostMapping("/api/metrics")
//    @ResponseBody
//    public String receiveMetrics(@RequestBody Metrics m) {
//        m.setTimestamp(LocalDateTime.now());
//        m.setStatus("UP");
//        metricsMap.put(m.getHostname(), m);
//        return "OK";
//    }
//
//    @GetMapping("/")
//    public String dashboard(Model model) {
//        LocalDateTime now = LocalDateTime.now();
//        for (Metrics m : metricsMap.values()) {
//            if (m.getTimestamp().isBefore(now.minusMinutes(2))) {
//                m.setStatus("DOWN");
//            }
//        }
//        model.addAttribute("metrics", metricsMap.values());
//        return "dashboard";
//    }
//
//
//}