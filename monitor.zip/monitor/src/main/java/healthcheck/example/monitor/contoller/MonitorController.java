package healthcheck.example.monitor.contoller;

import healthcheck.example.monitor.service.UrlCheckerService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MonitorController {

    private final UrlCheckerService urlCheckerService;

    public MonitorController(UrlCheckerService urlCheckerService) {
        this.urlCheckerService = urlCheckerService;
    }

    @GetMapping("/")
    public String dashboard(Model model) {
        model.addAttribute("sites", urlCheckerService.checkSites());
        return "dashboard";
    }
} 