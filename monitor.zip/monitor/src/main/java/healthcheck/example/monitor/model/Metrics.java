package healthcheck.example.monitor.model;

import java.time.LocalDateTime;

public class Metrics {
    private String hostname;
    private double cpu;
    private double memory;
    private double disk;
    private LocalDateTime timestamp = LocalDateTime.now();
    private String status; // "UP" or "DOWN"
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getHostname() { return hostname; }
    public void setHostname(String hostname) { this.hostname = hostname; }

    public double getCpu() { return cpu; }
    public void setCpu(double cpu) { this.cpu = cpu; }

    public double getMemory() { return memory; }
    public void setMemory(double memory) { this.memory = memory; }

    public double getDisk() { return disk; }
    public void setDisk(double disk) { this.disk = disk; }

    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }
}
