package healthcheck.example.monitor.model;
import java.time.LocalDateTime;

public class SiteStatus {
    private String name;
    private String url;
    private String status;
    private long responseTime;
    private LocalDateTime lastChecked;
    private long responseTimeMs;

    public long getResponseTimeMs() {
        return responseTimeMs;
    }

    public void setResponseTimeMs(long responseTimeMs) {
        this.responseTimeMs = responseTimeMs;
    }
    public SiteStatus(String name, String url, String status, long responseTime, LocalDateTime lastChecked) {
        this.name = name;
        this.url = url;
        this.status = status;
        this.responseTime = responseTime;
        this.lastChecked = lastChecked;
    }

    // Getters
    public String getName() { return name; }
    public String getUrl() { return url; }
    public String getStatus() { return status; }
    public long getResponseTime() { return responseTime; }
    public LocalDateTime getLastChecked() { return lastChecked; }
}