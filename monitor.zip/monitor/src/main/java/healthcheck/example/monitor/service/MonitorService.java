//package healthcheck.example.monitor.service;
//
//import healthcheck.example.monitor.model.SiteStatus;
//import jakarta.annotation.PostConstruct;
//import org.springframework.scheduling.annotation.Scheduled;
//import org.springframework.stereotype.Service;
//
//import java.net.HttpURLConnection;
//import java.net.URL;
//import java.time.LocalDateTime;
//import java.util.*;
//
//@Service
//public class MonitorService {
//    private final List<SiteStatus> sites = new ArrayList<>();
//
//    @PostConstruct
//    public void initSites() {
//        sites.add(new SiteStatus("QA1", "https://qa1.hwlmsp.com"));
//        sites.add(new SiteStatus("QA2", "https://qa2.hwlmsp.com"));
//        sites.add(new SiteStatus("VMS", "https://vms.hwlmsp.com"));
//        sites.add(new SiteStatus("QA3", "https://qa3.hwlmsp.com"));
//        sites.add(new SiteStatus("QA5", "https://qa5.hwlmsp.com"));
//        sites.add(new SiteStatus("QA6", "https://qa6.hwlmsp.com"));
//        sites.add(new SiteStatus("QA7", "https://qa7.hwlmsp.com"));
//    }
//
//    @Scheduled(fixedRate = 60000) // every 1 min
//    public void checkSites() {
//        for (SiteStatus site : sites) {
//            long start = System.currentTimeMillis();
//            try {
//                HttpURLConnection conn = (HttpURLConnection) new URL(site.getUrl()).openConnection();
//                conn.setConnectTimeout(5000);
//                conn.setReadTimeout(5000);
//                conn.setRequestMethod("GET");
//                int code = conn.getResponseCode();
//                site.setStatus(code == 200 ? "UP" : "DOWN");
//            } catch (Exception e) {
//                site.setStatus("DOWN");
//            }
//            site.setResponseTimeMs(System.currentTimeMillis() - start);
//            site.setLastChecked(LocalDateTime.now());
//        }
//    }
//
//    public List<SiteStatus> getSites() {
//        return sites;
//    }
//}