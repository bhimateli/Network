package healthcheck.example.monitor.service;

import healthcheck.example.monitor.model.SiteStatus;
import org.springframework.stereotype.Service;

import java.net.HttpURLConnection;
import java.net.URL;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class UrlCheckerService {

    private final List<SiteStatus> sites = new ArrayList<>();

    public List<SiteStatus> checkSites() {
        sites.clear();

        checkSite("QA1", "http://qa1.hwlmsp.com");
        checkSite("QA2", "http://qa2.hwlmsp.com");
        checkSite("VMS", "https://vms.hwlmsp.com");
        checkSite("QA3", "http://qa3.hwlmsp.com");
        checkSite("QA5", "http://qa5.hwlmsp.com");
        checkSite("QA6", "http://qa6.hwlmsp.com");
        checkSite("QA7", "http://qa7.hwlmsp.com");

        return sites;
    }

    private void checkSite(String name, String url) {
        long start = System.currentTimeMillis();
        String status = "DOWN";

        try {
            HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
            connection.setRequestMethod("HEAD");
            connection.setConnectTimeout(3000);
            connection.connect();

            int code = connection.getResponseCode();
            if (code >= 200 && code < 400) {
                status = "UP";
            }
        } catch (Exception ignored) {
        }

        long time = System.currentTimeMillis() - start;
        sites.add(new SiteStatus(name, url, status, time, LocalDateTime.now()));
    }
}