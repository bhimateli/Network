package network.social.common;

import org.testng.ITestResult;
import org.testng.TestListenerAdapter;
import org.testng.annotations.Test;

public class SocialApiListener extends TestListenerAdapter {

	@Override
	public void onTestStart(ITestResult tr) {
		System.out.println(
				"============================================================================================================================");
		System.out.println("STARTED - " + tr.getTestClass().getName() + "#" + tr.getName());
		System.out.println(
				"============================================================================================================================");
	}

	@Override
	public void onTestSuccess(ITestResult tr) {
		System.out.println(
				"============================================================================================================================");
		System.out.println("PASSED - " + tr.getTestClass().getName() + "#" + tr.getName());
		System.out.println(
				"============================================================================================================================");
	}

	@Override
	public void onTestFailure(ITestResult tr) {
		System.out.println(
				"============================================================================================================================");
		System.out.println("FAILED - " + tr.getTestClass().getName() + "#" + tr.getName());

		// Added for B-26825 (unRegister User check condition starts)

	
		// Added for B-26825 (unRegister User check condition ends)

		System.out.println(
				"============================================================================================================================");
		System.out.println(
				"============================================================================================================================");
		System.out.println("FAILURE REASON");
		System.out.println(tr.getThrowable());
		System.out.println(
				"============================================================================================================================");
	}

	@Override
	public void onTestSkipped(ITestResult tr) {
		System.out.println(
				"============================================================================================================================");
		System.out.println("SKIPPED - " + tr.getTestClass().getName() + "#" + tr.getName());
		System.out.println(
				"============================================================================================================================");
	}

}