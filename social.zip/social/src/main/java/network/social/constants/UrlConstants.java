package network.social.constants;

import org.testng.annotations.Test;

public class UrlConstants {
	public final static String POST_API = "/posts";
	public final static String COMMENTS_API = "/comments";
	public final static String USER_API = "/users";
}
