package network.social.helper;

import java.util.Random;

import org.testng.annotations.Test;

public class POSTAndCommentUtils {
	
	public String generateRandomString() {

		int leftLimit = 97; // letter 'a'
		int rightLimit = 122; // letter 'z'
		int targetStringLength = 10;
		Random random = new Random();
		StringBuilder buffer = new StringBuilder(targetStringLength);
		for(int k=0 ;k<15;k++) {
		for (int i = 0; i < targetStringLength; i++) {
			int randomLimitedInt = leftLimit + (int) (random.nextFloat() * (rightLimit - leftLimit + 1));
			buffer.append((char) randomLimitedInt) ;
			
		} buffer.append(" ");
		}
		String generatedString = buffer.toString();

		System.out.println(generatedString);
		return generatedString;
	}
}
