package network.social.utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.testng.Reporter;
import org.testng.annotations.Test;


public class PropertyFileSource {
	public Properties loadParameters(String configFile) {
		Properties prop = new Properties();
		InputStream inputStream = null;
		try {
			inputStream = new FileInputStream(configFile);
			prop.load(inputStream);
		} catch (Exception e) {
			try {
				prop.load(PropertyFileSource.class.getResourceAsStream("/" + configFile));
			} catch (IOException e1) {
				System.out.println("Exception while loading properties file:::" + configFile);
				Reporter.log("Exception while loading properties file:::" + configFile);
				e1.printStackTrace();
			}
		} finally {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException e) {
					System.out.print("Exception in loadParameters(1P)::" + configFile);
					Reporter.log("Exception in loadParameters(1P)::" + configFile);
					e.printStackTrace();
				}
			}
		}
		return prop;
	}
}
