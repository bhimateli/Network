package network.social.comments;

import java.util.HashMap;
import java.util.Map;

import org.databene.benerator.anno.Source;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Assert;
import org.testng.annotations.Test;

import io.restassured.response.Response;
import network.social.common.Begin;
import network.social.common.Configurations;
import network.social.constants.UrlConstants;
import network.social.helper.CreateJsonBody;
import network.social.helper.POSTAndCommentUtils;
import network.social.pojo.HttpMethodParameter;
import network.social.utils.RestUtils;

public class CommentsAPITest extends Begin {
	Configurations configurationObj = Configurations.getInstance();
	RestUtils restUtil = new RestUtils();
	CreateJsonBody createJson = new CreateJsonBody();
	POSTAndCommentUtils postObj = new POSTAndCommentUtils();
	
	@Test(dataProvider = "feeder")
	@Source("\\CommentsAPITestCases.csv")
	public void postCommentsAPITest(String testCaseId,String testCaseName,String emailName,String emailValue,String bodyName,String bodyValue,String postIdName,String postIdValue,String checkPoint,String name,String nameValue,String enabled) {
		
		HttpMethodParameter httParams = HttpMethodParameter.builder().build();
		if(bodyValue.equalsIgnoreCase("value"))
		 bodyValue =postObj.generateRandomString();
		 System.out.println("Generated random String  " + bodyValue);
		String jsonObject = createJson.createCommentInputBody(emailName, emailValue, bodyName,	bodyValue, postIdName,postIdValue,name,nameValue);
		System.out.println("Json Object  " + jsonObject);
		httParams.setBodyParams(jsonObject);
		Response postResponse = restUtil.PostOpertion(httParams, UrlConstants.COMMENTS_API,
				configurationObj.getContentType());			
		/*
		 * After posting - validating the attributes and its values with static values. We need to compare standard values
		 * Better approach for validating attribute is schema validation. But to validate value then we have to do this as well.
		 */
		
		Assert.assertEquals(201, postResponse.getStatusCode());
		JSONObject obj1 = new JSONObject(postResponse.prettyPrint());
		   if(checkPoint.equalsIgnoreCase("VALID")) {
			
			Assert.assertEquals(bodyValue, obj1.getString(bodyName));
			Assert.assertEquals(emailValue, obj1.getString(emailName));
			Assert.assertEquals(postIdValue, String.valueOf(obj1.getLong(postIdName)));
			Assert.assertEquals(nameValue, obj1.getString(name));
			
		   }else if(checkPoint.equalsIgnoreCase("EMAIL"))
		   {
			   Assert.assertEquals(emailValue, obj1.getString(emailName));
		   }else if(checkPoint.equalsIgnoreCase("POSTID"))
		   {
			   Assert.assertEquals(postIdValue, String.valueOf(obj1.getLong(postIdName)));
			   
		   }else if(checkPoint.equalsIgnoreCase("BODY"))
		   {
			   Assert.assertEquals(bodyValue, obj1.getString(bodyName));
		   }else if(checkPoint.equalsIgnoreCase("NAME"))
		   {
			   Assert.assertEquals(nameValue, obj1.getString(name));
		   }
			Assert.assertNotNull(obj1.getLong("id"));
		
	}
	
	@Test(dataProvider = "feeder")
	@Source("\\CommentsAPIGETTestCases.csv")
	public void getCommentsURIAndValidateTest(String testCaseId,String testCaseName,String queryParamName,String queryParamValue,String enabled) {

		HttpMethodParameter httpParams = HttpMethodParameter.builder().build();

		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put(queryParamName, queryParamValue);
		httpParams.setQueryParams(queryParams);
		Response getResponse = restUtil.getOperation(httpParams, UrlConstants.COMMENTS_API,configurationObj.getContentType());
		
		Assert.assertEquals(200, getResponse.getStatusCode());
		System.out.println("Response is " + getResponse.prettyPrint());
		JSONArray obj = new JSONArray(getResponse.prettyPrint());
		if ((queryParamName.equalsIgnoreCase("EMPTY") && queryParamValue.equalsIgnoreCase("EMPTY"))) {
			System.out.println("The total posts are " + obj.length());
			Assert.assertEquals(configurationObj.getCommentsCount(), String.valueOf(obj.length()));

			/*
			 * verify email and body should be part of response - if schema validation is
			 * done then we can remove this code.
			 */
			for (int i = 0; i < obj.length(); i++) {
				JSONObject obj1 = obj.getJSONObject(i);

				Assert.assertNotNull(obj1.getString("email"));
				Assert.assertNotNull(obj1.getString("body"));
				Assert.assertNotNull(obj1.getString("name"));
				Assert.assertNotNull(obj1.getLong("postId"));
				Assert.assertNotNull(obj1.getLong("id"));
				
			}

		} else {
			JSONObject obj1 = obj.getJSONObject(0);
            if(queryParamName.equalsIgnoreCase("email")) {
            	Assert.assertEquals(queryParamValue, (obj1.getString(queryParamName)));
            }else
            {
            	Assert.assertEquals(queryParamValue, String.valueOf(obj1.getLong(queryParamName)));
            }
			
			Assert.assertNotNull(obj1.getString("email"));
			Assert.assertNotNull(obj1.getString("body")); // Verifying the attribute part of response
			Assert.assertNotNull(obj1.getString("name"));
			Assert.assertNotNull(obj1.getLong("postId"));
			Assert.assertNotNull(obj1.getLong("id"));
		}
			
	}

}
