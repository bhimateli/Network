package network.social.cucumber;

import org.json.JSONObject;
import org.junit.Assert;
import org.testng.annotations.Test;

import cucumber.api.java.en.Given;
import io.restassured.response.Response;
import network.social.common.Begin;
import network.social.common.Configurations;
import network.social.constants.UrlConstants;
import network.social.helper.CreateJsonBody;
import network.social.helper.POSTAndCommentUtils;
import network.social.pojo.HttpMethodParameter;
import network.social.utils.RestUtils;

public class CucumberPostApiTest extends Begin {
	Configurations configurationObj = Configurations.getInstance();
	RestUtils restUtil = new RestUtils();
	CreateJsonBody createJson = new CreateJsonBody();
	POSTAndCommentUtils postObj = new POSTAndCommentUtils();
	
	@Given("^Pass the body and post it \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void pass_the_body_and_post_it_and_and_and_and_and_and(String titleName, String titleValue, String bodyName, String bodyValue, String userIdName, String userIdValue, String checkPoint) throws Throwable {
	   
		HttpMethodParameter httParams = HttpMethodParameter.builder().build();
		if(bodyValue.equalsIgnoreCase("value"))
		 bodyValue =postObj.generateRandomString();
		 System.out.println("Generated random String  " + bodyValue);
		String jsonObject = createJson.createPOSTInputBody(titleName, titleValue, bodyName,	bodyValue, userIdName,userIdValue);
		System.out.println("Json Object  " + jsonObject);
		httParams.setBodyParams(jsonObject);
		Response postResponse = restUtil.PostOpertion(httParams, UrlConstants.POST_API,
				configurationObj.getContentType());			
		/*
		 * After posting - validating the attributes and its values with static values. We need to compare standard values
		 * Better approach for validating attribute is schema validation. But to validate value then we have to do this as well.
		 */
		
		Assert.assertEquals(201, postResponse.getStatusCode());
		JSONObject obj1 = new JSONObject(postResponse.prettyPrint());
		   if(checkPoint.equalsIgnoreCase("VALID")) {
			
			Assert.assertEquals(bodyValue, obj1.getString(bodyName));
			Assert.assertEquals(titleValue, obj1.getString(titleName));
			Assert.assertEquals(userIdValue, String.valueOf(obj1.getLong(userIdName)));
			
		   }else if(checkPoint.equalsIgnoreCase("TITLE"))
		   {
			   Assert.assertEquals(titleValue, obj1.getString(titleName));
		   }else if(checkPoint.equalsIgnoreCase("USERID"))
		   {
			   Assert.assertEquals(userIdValue, String.valueOf(obj1.getLong(userIdName)));
			   
		   }else if(checkPoint.equalsIgnoreCase("BODY"))
		   {
			   Assert.assertEquals(bodyValue, obj1.getString(bodyName));
		   }
			Assert.assertNotNull(obj1.getLong("id"));
		
	}
}
