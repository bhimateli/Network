package network.social.cucumber;

import java.util.HashMap;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.Test;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.response.Response;
import junit.framework.Assert;
import network.social.common.Begin;
import network.social.common.Configurations;
import network.social.constants.UrlConstants;
import network.social.pojo.HttpMethodParameter;
import network.social.utils.RestUtils;

public class CucumberUserAPITest extends Begin {
	Configurations configurationObj = Configurations.getInstance();
	RestUtils restUtil = new RestUtils();
	HttpMethodParameter httpParams = HttpMethodParameter.builder().build();
	Map<String, String> queryParams = new HashMap<String, String>();
	Map<String, Object> pathParams = new HashMap<String, Object>();
	Response getResponse;
	
	@Given("^Pass the query Parameter and its value \"([^\"]*)\" and   \"([^\"]*)\"$")
	public void pass_the_query_Parameter_and_its_value_and(String queryParamName, String queryParamValue) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
			queryParams.put(queryParamName, queryParamValue);			
			httpParams.setQueryParams(queryParams);
			 getResponse = restUtil.getOperation(httpParams, UrlConstants.USER_API,
					configurationObj.getContentType());
			 Assert.assertEquals(200, getResponse.getStatusCode());				
					
						JSONArray obj = new JSONArray(getResponse.prettyPrint());
						System.out.println("The total users are "+obj.length());												
						
						for (int i = 0; i < obj.length(); i++) {
							JSONObject obj1 = obj.getJSONObject(i);
							if(queryParamName.equalsIgnoreCase("id")) {
								Assert.assertEquals(queryParamValue, String.valueOf(obj1.getLong(queryParamName)));
							}else
							Assert.assertEquals(queryParamValue, obj1.getString(queryParamName));
							
							Assert.assertNotNull(obj1.getString("username"));
						}
					
				
	}
	
	@Given("^call get user and verify total number of users and attributes$")
	public void call_get_user_and_verify_total_number_of_users_and_attributes() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		queryParams.put("", "");
		httpParams.setQueryParams(queryParams);
		 getResponse = restUtil.getOperation(httpParams, UrlConstants.USER_API,
					configurationObj.getContentType());
		 JSONArray obj = new JSONArray(getResponse.prettyPrint());
		 System.out.println("The total users are "+obj.length());
		 Assert.assertEquals(configurationObj.getUsersCount(), String.valueOf(obj.length()));
		 for (int i = 0; i < obj.length(); i++) {
				JSONObject obj1 = obj.getJSONObject(i);
				Assert.assertNotNull(obj1.getString("username"));
				Assert.assertNotNull(obj1.getString("name"));
				Assert.assertNotNull(obj1.getString("email"));
				Assert.assertNotNull(obj1.getString("website"));
				Assert.assertNotNull(obj1.getString("phone"));
				
		 }
		 
	}
	
}
