package network.social.posts;

import java.util.HashMap;
import java.util.Map;

import org.databene.benerator.anno.Source;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Assert;
import org.testng.annotations.Test;
import io.restassured.response.Response;
import network.social.common.Begin;
import network.social.common.Configurations;
import network.social.constants.UrlConstants;
import network.social.helper.CreateJsonBody;
import network.social.helper.POSTAndCommentUtils;
import network.social.pojo.HttpMethodParameter;
import network.social.utils.RestUtils;

public class PostComments extends Begin {
	Configurations configurationObj = Configurations.getInstance();
	RestUtils restUtil = new RestUtils();
	CreateJsonBody createJson = new CreateJsonBody();
	POSTAndCommentUtils postObj = new POSTAndCommentUtils();

	/*
	 * API: https://jsonplaceholder.typicode.com/posts create json input for above
	 * API and send request. After getting the response validate the response.
	 */

	@Test(dataProvider = "feeder")
	@Source("\\POSTAPITestCases.csv")
	public void postURIAndValidateTest(String testCaseId,String testCaseName,String titleName,String titleValue,String bodyName,String bodyValue,String userIdName,String userIdValue,String checkPoint,String enabled ) {
		HttpMethodParameter httParams = HttpMethodParameter.builder().build();
		if(bodyValue.equalsIgnoreCase("value"))
		 bodyValue =postObj.generateRandomString();
		 System.out.println("Generated random String  " + bodyValue);
		String jsonObject = createJson.createPOSTInputBody(titleName, titleValue, bodyName,	bodyValue, userIdName,userIdValue);
		System.out.println("Json Object  " + jsonObject);
		httParams.setBodyParams(jsonObject);
		Response postResponse = restUtil.PostOpertion(httParams, UrlConstants.POST_API,
				configurationObj.getContentType());			
		/*
		 * After posting - validating the attributes and its values with static values. We need to compare standard values
		 * Better approach for validating attribute is schema validation. But to validate value then we have to do this as well.
		 */
		
		Assert.assertEquals(201, postResponse.getStatusCode());
		JSONObject obj1 = new JSONObject(postResponse.prettyPrint());
		   if(checkPoint.equalsIgnoreCase("VALID")) {
			
			Assert.assertEquals(bodyValue, obj1.getString(bodyName));
			Assert.assertEquals(titleValue, obj1.getString(titleName));
			Assert.assertEquals(userIdValue, String.valueOf(obj1.getLong(userIdName)));
			
		   }else if(checkPoint.equalsIgnoreCase("TITLE"))
		   {
			   Assert.assertEquals(titleValue, obj1.getString(titleName));
		   }else if(checkPoint.equalsIgnoreCase("USERID"))
		   {
			   Assert.assertEquals(userIdValue, String.valueOf(obj1.getLong(userIdName)));
			   
		   }else if(checkPoint.equalsIgnoreCase("BODY"))
		   {
			   Assert.assertEquals(bodyValue, obj1.getString(bodyName));
		   }
			Assert.assertNotNull(obj1.getLong("id"));
		

	}

	/*
	 * API: https://jsonplaceholder.typicode.com/posts Call above api and verify.
	 * Use different query parameters and validate
	 */

	@Test(dataProvider = "feeder")
	@Source("\\POSTAPIGETTestCases.csv")
	public void getPostURIAndValidateTest(String testCaseId,String testCaseName,String queryParamName,String queryParamValue,String enabled) {

		HttpMethodParameter httpParams = HttpMethodParameter.builder().build();

		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put(queryParamName, queryParamValue);
		httpParams.setQueryParams(queryParams);
		Response getResponse = restUtil.getOperation(httpParams, UrlConstants.POST_API,configurationObj.getContentType());
		
		Assert.assertEquals(200, getResponse.getStatusCode());
		System.out.println("Response is " + getResponse.prettyPrint());
		JSONArray obj = new JSONArray(getResponse.prettyPrint());
		if ((queryParamName.equalsIgnoreCase("EMPTY") && queryParamValue.equalsIgnoreCase("EMPTY"))) {
			System.out.println("The total posts are " + obj.length());
			Assert.assertEquals(configurationObj.getPostsCount(), String.valueOf(obj.length()));

			/*
			 * verify title and body should be part of response - if schema validation is
			 * done then we can remove this code.
			 */
			for (int i = 0; i < obj.length(); i++) {
				JSONObject obj1 = obj.getJSONObject(i);

				Assert.assertNotNull(obj1.getString("title"));
				Assert.assertNotNull(obj1.getString("body"));
				
			}

		} else {
			JSONObject obj1 = obj.getJSONObject(0);

			Assert.assertEquals(queryParamValue, String.valueOf(obj1.getLong(queryParamName)));
			Assert.assertNotNull(obj1.getString("title"));
			Assert.assertNotNull(obj1.getString("body")); // Verifying the attribute part of response

		}
			
	}

	

}
