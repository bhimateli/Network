package network.social.user;

import java.util.HashMap;
import java.util.Map;

import org.databene.benerator.anno.Source;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.Test;

import io.restassured.response.Response;
import junit.framework.Assert;
import network.social.common.Begin;
import network.social.common.Configurations;
import network.social.constants.UrlConstants;
import network.social.pojo.HttpMethodParameter;
import network.social.utils.RestUtils;

public class UserAPITest extends Begin {
	Configurations configurationObj = Configurations.getInstance();
	RestUtils restUtil = new RestUtils();
	String queryParamName = "";
	String queryParamValue = "";
/*
 * POSTIVE TEST CASES - Few scenarios covered
 */
	@Test(dataProvider = "feeder")
	@Source("\\UserAPITestCases.csv")
	public void getUserAPITest(String testCaseId, String testCaseName, String queryParamName, String queryParamValue,
			String enable) {
		System.out.println("Pointer inside the method");
		HttpMethodParameter httpParams = HttpMethodParameter.builder().build();
		Map<String, String> queryParams = new HashMap<String, String>();
		Map<String, Object> pathParams = new HashMap<String, Object>();
		if (!(queryParamName.equalsIgnoreCase("EMPTY") || queryParamValue.equalsIgnoreCase("EMPTY")))
			queryParams.put(queryParamName, queryParamValue);
		pathParams.put(queryParamName, queryParamValue);
		httpParams.setQueryParams(queryParams);
		Response getResponse = restUtil.getOperation(httpParams, UrlConstants.USER_API,
				configurationObj.getContentType());

		Assert.assertEquals(200, getResponse.getStatusCode());
		if (!(queryParamName.equalsIgnoreCase("EMPTY") || queryParamValue.equalsIgnoreCase("EMPTY"))) {
			JSONArray obj = new JSONArray(getResponse.prettyPrint());
			JSONObject obj1 = obj.getJSONObject(0);			
			
			Assert.assertEquals(queryParamValue, obj1.getString(queryParamName));

		} else {
			/*
			 * Verify number of user and username is attribute is part of it.
			 * Assume we have created 10 users and now we should verify total number of users from APi.
			 * Read number of users from the properties file.(Dynamic values we cant verify).
			 */
				JSONArray obj = new JSONArray(getResponse.prettyPrint());
				System.out.println("The total users are "+obj.length());
						
				Assert.assertEquals(configurationObj.getUsersCount(), String.valueOf(obj.length()));
				//Assert.assertEquals(configurationObj.getUsersCount(), obj.length());
				
				for (int i = 0; i < obj.length(); i++) {
					JSONObject obj1 = obj.getJSONObject(i);
					
					Assert.assertNotNull(obj1.getString("username"));
				}
			
		}

	}
	
	/*
	 * Negative Test Cases  Few scenarios covered.
	 * 
	 */
	@Test(dataProvider = "feeder")
	@Source("\\UserAPITestCasesNegative.csv")
	public void getUserAPINegativeTest(String testCaseId, String testCaseName, String queryParamName, String queryParamValue,
			String enable) {
		
		HttpMethodParameter httpParams = HttpMethodParameter.builder().build();
		Map<String, String> queryParams = new HashMap<String, String>();
		Map<String, Object> pathParams = new HashMap<String, Object>();
		queryParams.put(queryParamName, queryParamValue);
		pathParams.put(queryParamName, queryParamValue);
		httpParams.setQueryParams(queryParams);
		Response getResponse = restUtil.getOperation(httpParams, UrlConstants.USER_API,
				configurationObj.getContentType());
		System.out.println("The length of the response is "+getResponse.prettyPrint().length());
		Assert.assertEquals(200, getResponse.getStatusCode());
		Assert.assertEquals(8, getResponse.prettyPrint().length()); // Empty response length always 8 so hardcoding and validating.
		
		
	}
	
	
}
